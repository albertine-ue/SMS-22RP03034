/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package connection;

import java.util.Scanner;
import java.sql.*;
public class crud {
private static final String URL="jdbc:mariadb://localhost:3306/ALISO";
private static final String USERNAME="root";
private static final String PASSWORD="";
  
public static void main(String[]args){
    Connection conn=null;
    Statement stmts=null;
    try{
      Class.forName("org.mariadb.jdbc.Driver");
      conn = DriverManager.getConnection(URL,USERNAME,PASSWORD);
      stmts=conn.createStatement();
      String sql="CREATE TABLE IF NOT EXISTS MOYI"+
       "(id INT PRIMARY KEY,"+
       "fname VARCHAR(20),"+
      "lname VARCHAR(8),"+
      "regno VARCHAR(5))";
      //String inserts="INSERT INTO STUDENTS VALUES(1,'FREDERIC',20,'M')";
      stmts.executeUpdate(sql);
      //stmts.executeUpdate(inserts);
Scanner input=new Scanner(System.in);
 System.out.println("Enter Students Id: ");
 String ids=input.nextLine();
 
 System.out.println("Enter Students fname: ");
 String names=input.nextLine();

 
 System.out.println("Enter Students lname: ");
 String lnm=input.nextLine();
 System.out.println("Enter Students regno: ");
 String regno=input.nextLine();
 
 //insert
 sql="INSERT INTO MOYI(id,fname,lname,regno) values(?,?,?,?)";
 PreparedStatement pst=conn.prepareStatement(sql);
 pst.setString(1,ids);
 pst.setString(2,names);
 pst.setString(3,lnm);
  pst.setString(4,regno);
 pst.executeUpdate();
 
}
    
    catch(SQLException e){
        e.printStackTrace(); 
    }
    catch(Exception e){
       e.printStackTrace();
    }}}
  