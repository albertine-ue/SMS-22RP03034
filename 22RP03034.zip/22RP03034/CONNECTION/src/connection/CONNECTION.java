/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package connection;

/**
 *
 * @author user
 */
import java.sql.*;
public class CONNECTION {

  
private static final String URL="jdbc:mariadb://localhost:3306";
private static final String USERNAME="root";
private static final String PASSWORD="";
    /**
     * @param args the command line arguments
     */
    public static void main(String[]args) {
        Connection conn=null;
    try{
        conn = DriverManager.getConnection(URL,USERNAME,PASSWORD);
        if(conn!=null){
            System.out.println("Connected success full"); 
        }
        else{
            System.out.println("failed Connected"); 
        }
    }
    catch(SQLException e){
         System.out.println("Error"+e.getMessage());
    }
    
    finally{
        if(conn!=null){
            try{
                conn.close();
                  System.out.println("Connection closed");
             }
         catch(SQLException e){
                e.printStackTrace();
                System.out.println("Error");
           }
        }
        
    }  
    
    }
    
}

       
   
