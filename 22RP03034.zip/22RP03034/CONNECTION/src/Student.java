/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class Student {
    private String name;
    private String rollNumber;
    private int mathMarks;
    private int javaMarks;
    private int phpMarks;

    public Student(String name, String rollNumber, int mathMarks, int javaMarks, int phpMarks) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.mathMarks = mathMarks;
        this.javaMarks = javaMarks;
        this.phpMarks = phpMarks;
    }

    public String getName() {
        return name;
    }

    public String getRollNumber() {
        return rollNumber;
    }

    public int getMathMarks() {
        return mathMarks;
    }

    public int getJavaMarks() {
        return javaMarks;
    }

    public int getPhpMarks() {
        return phpMarks;
    }

    public double getAverageMarks() {
        return (mathMarks + javaMarks + phpMarks) / 3.0;
    }
}



  

